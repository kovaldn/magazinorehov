(function() {
   
    var app = {
         
        initialize : function () {   
            app.build();  // рендерим дом объекты из json файла  
        },

        resultArea: $('#order'),

        order: {},

        goods: {},

        totalPrice: 0,

        build: function () {

            $.ajax({
                url: 'data.json'
            }).done(function(data){

                app.goods = data;

                Handlebars.registerHelper('htmlback', function(object) {
                  return new Handlebars.SafeString(
                    "<p class='label'><span>" + object + "</span></p>"
                  );
                });

                var source   = $("#blocks").html(),
                    template = Handlebars.compile(source),
                    html    = template(data);

                $('#product-area').append(html);   

                // когда DOM готов 
                app.modules(); // подключаем модули, 
                app.setUpListeners(); // подключаем прослушку 

            }).fail(function(data){
                console.log(data); // в случае ошибки в json 
            });
        },
 
        modules: function () {
            var spinner = $( ".spinners" ).spinner({max: 8, min: 0}); // подключаем jquery ui
        },
 
        setUpListeners: function () {
            $( ".spinners" ).on( "spin", app.spin ); // простлушка на увеличение/уменьшение значения инпута
            $("#order-form").on('submit', app.formSubmit);
            $(".box img, .box .label").on('click', app.addOne);
            $('.cart-box').on('click', app.showModal);
            $(window).on( 'scroll', app.scroll);
        },

        scroll: function () {
            var top = $(window).scrollTop();
            if (top > 400) {
                $(".cart-box").addClass("cart_fixed");
            } else {
                $(".cart-box").removeClass("cart_fixed");
            }
        },

        showModal: function () {
            if(app.orderStatus === 'filled'){
                app.renderOrder();
                $('.alert').hide();
                $('#myModal').modal('show');                
            }else{
                $('.alert').show();
            }
        },
 
        spin: function (event, ui) {

            $('.alert').hide();

            var thisInput = event.currentTarget,
                value = ui.value,
                productName = $(thisInput).attr('data');
            
            app.preOrder(value, productName);           
            
        },

        preOrder: function (value, productName ) {

            if (value === 0){
                delete app.order[productName];
            } else {
                app.order[productName] = value;
            }
            
            app.totalPriceFun();

        },

        addOne: function (ev) {

            $('.alert').hide();

            var that = event.currentTarget,
                input = $(that).nextAll('.info').children('.ui-spinner').children('.ui-spinner-input'),
                productName = input.attr('data'),
                currentVal = input.val(),
                newVal = parseInt(currentVal) + 1;

            input.val(newVal);
            app.preOrder(newVal, productName);
        },

        renderOrder: function () {

            // создаём объект данных, при помощи которого будем заполнять шаблон
            var data = {
                order: []
            };

            // заполним его данными о товарах
            $.each(app.order, function(index, val) {
                data.order.push({
                    'productName' : index, // наименование
                    'amount' : val
                });
            });

            // добавим в него общую стоимость заказа
            data.totalPrice = app.totalPrice;

            // Handlebars
            var source   = $("#order-template").html(),
                template = Handlebars.compile(source),
                html    = template(data);

            $('#order').html(html);

            var spinner = $( ".spinners" ).spinner({max: 8, min: 0}); // подключаем jquery ui

        },

        totalPriceFun: function () {

            var totalPrice = 0,
                numberOfProducts = 0,
                res;
            
            for(var key in app.order) {

                var currentItem = key, // например "фундук"
                    amount = app.order[key]; // например "3" (кило)

                numberOfProducts = numberOfProducts + amount; // сколько всего товаров в корзине
              
                // пройдемся по массиву товаров, чтобы узнать цену
                _.each(app.goods.blocks, function (element, index, list) {
                     if (currentItem === element.rus) {
                        totalPrice = totalPrice + parseInt(element.price) * amount;
                    }
                });

            }

            if (numberOfProducts !== 0){
                res = '<b>' + numberOfProducts + '</b> товаров на <b>' + totalPrice + '</b> рублей';                
                app.orderStatus = 'filled';
            }else{
                res = 'Ваша корзина пуста';
                app.orderStatus = 'empty';
            }

            app.totalPrice = totalPrice;
            
            $('#status').html(res);
        },

        formSubmit: function (ev) {

            // console.log('formSubmit');
            
            ev.preventDefault();

            var str = $(this).serialize();    

            // console.log($(this));
            // console.log(str);

            $.ajax({
                type: "POST",
                url: "contact_form/contact_process.php",
                data: str,
                success: function(msg) {

                    if(msg == 'OK') {
                        var result = '<div class="notification_ok">Спасибо за ваш заказ! Мы свяжемся с вами в течение 15 минут.</div>';
                        $("#order-form").html(result);
                    } else {
                        $(".msg").html(msg);
                    }
                }
            });
            return false;
        }       
         
    }
 
    app.initialize();
 
}());
