<?php
	define("CONTACT_FORM", 'kovaldn@gmail.com');
?>